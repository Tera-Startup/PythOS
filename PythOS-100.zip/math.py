import time

print("\n[1] Addition ")
time.sleep(0.5)

print("[2] Substraction")
time.sleep(0.5)

print("[3] Multiplication")
time.sleep(0.5)

print("[4] Division")
time.sleep(0.5)

print("[5] Stop")

Methode = input("\n--> ")
Methode = str(Methode)

if str(Methode) == '1':

    time.sleep(0.5)
    print("\nYou have chosen addition.")
    time.sleep(0.5)
    x = input("\nNumber 1 --> ")
    nombreNombre = 1
    time.sleep(0.5)
    y = input("Number 2 --> ")
    nombreNombre == 2
    x = float(x)
    y = float(y)
    time.sleep(0.5)
    print("\nThe result is {}".format(float(x) + float(y)))
    time.sleep(1)
    exec(open("./math.py").read())

if str(Methode) == "2":
    time.sleep(0.5)
    print("\nYou have chosen substraction.")
    time.sleep(0.5)
    x = input("\nNumber 1 --> ")
    time.sleep(0.5)
    y = input("Number 2 -->")
    x = float(x)
    y = float(y)
    print("\nThe result is {}".format(float(x) - float(y)))
    time.sleep(1)
    exec(open("./math.py").read())

if str(Methode) == '3':
    time.sleep(0.5)
    print("\nYou have chosen multiplication.")
    time.sleep(0.5)
    x = input("\nNumber 1 --> ")
    time.sleep(0.5)
    y = input("Number 2 --> ")
    x = float(x)
    y = float(y)
    print("\nThe result is {}".format(float(x) * float(y)))
    time.sleep(1)
    exec(open("./math.py").read())

if str(Methode) == "4":
    print("\nYou have chosen division.")
    x = input("\nNumber 1 -->")
    y = input("Number 2 --> ")
    x = float(x)
    y = float(y)
    print("\nThe result is {}".format(float(x) / float(y)))
    time.sleep(1)
    exec(open("./math.py").read())

if str(Methode) == "5":
    print("\nMaths stopped...")
    time.sleep(1)
    exec(open("./menu.py").read())