import time

nombreNombre = 0


def main():
    intro = "Welcome in PythOS !\nThis OS is in Pre pre pre pre pre pre Alpha,\nso if you see a bug : tell us !\nA game is coming soon in PythOS !"
    print(intro)
    time.sleep(0.5)

    choicesMenu = "\n[1] Menu"
    choicesAbout = "[2] About"

    print(choicesMenu)
    time.sleep(0.5)
    print(choicesAbout)
    time.sleep(0.5)
    print("[3] Shut down")


main()
choices1 = input("\n--> ")
if choices1 == "1":
    time.sleep(0.5)
    exec(open("./menu.py").read())
    choices2 = input("\n--> ")
    if choices2 == "1":
            exec(open("./math.py").read())

       

if choices1 == "2":
    time.sleep(0.5)
    print("\nABOUT :\n")
    exec(open("./about.py").read())
    main()
    
if choices1 == "3" or "shut down" or "stop":

    def shuttingDown():
        time.sleep(0.5)
        print("\nPythOS is shutting down...\n")
        time.sleep(1)
        quit()
    shuttingDown()