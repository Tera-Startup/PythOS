import time

time.sleep(0.5)
print("Original creator and main developer : Jules Auburtin\nSecondary developer : Gustave Dufresne Walter\n\n")
time.sleep(2)
exec(open("./main.py").read())