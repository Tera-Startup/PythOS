import time

print("\nMENU:\n")
time.sleep(0.5)

print("[1] Maths")
time.sleep(0.5)

#print("[2] Settings")
#time.sleep(0.5)

#print("[3] Files Explorer")
#time.sleep(0.5)

#print("[4] Shell")
#time.sleep(0.5)

#print("[5] Help")
#time.sleep(0.5)